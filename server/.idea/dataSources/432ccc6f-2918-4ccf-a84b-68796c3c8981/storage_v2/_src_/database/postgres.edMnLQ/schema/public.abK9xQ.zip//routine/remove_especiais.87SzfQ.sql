create function remove_especiais(texto text) returns text
    language plpgsql
as
$$
            BEGIN
            RETURN regexp_replace(unaccent(texto), '[^a-zA-Z0-9 ]', '', 'g');
            END;
            $$;

alter function remove_especiais(text) owner to unico;

