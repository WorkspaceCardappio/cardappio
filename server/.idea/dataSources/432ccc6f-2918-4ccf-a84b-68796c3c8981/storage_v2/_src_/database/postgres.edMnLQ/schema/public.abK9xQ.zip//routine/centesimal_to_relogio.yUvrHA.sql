create function centesimal_to_relogio(centesimal numeric) returns text
    language plpgsql
as
$$
            BEGIN
              RETURN TO_CHAR(ROUND(centesimal + 0.0005, 3) * '1 HOUR'::INTERVAL, 'HH24:MI');
            END;
            $$;

alter function centesimal_to_relogio(numeric) owner to unico;

