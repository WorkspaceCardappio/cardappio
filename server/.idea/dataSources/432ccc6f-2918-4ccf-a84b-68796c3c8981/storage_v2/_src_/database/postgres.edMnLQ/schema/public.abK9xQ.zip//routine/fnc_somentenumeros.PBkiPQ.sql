create function fnc_somentenumeros(texto character varying) returns text
    language plpgsql
as
$$
                begin
                    return regexp_replace(texto, '\D','','g' );
            END; $$;

alter function fnc_somentenumeros(varchar) owner to unico;

