create function dataporextenso(datarecebida date) returns text
    language plpgsql
as
$$
            DECLARE mes_extenso character varying;
            BEGIN

            mes_extenso = (ARRAY['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'])[EXTRACT(MONTH FROM datarecebida)];

            RETURN concat(to_char(datarecebida, 'DD'), ' de ', mes_extenso, ' de ', to_char(datarecebida, 'YYYY'));
            END;
            $$;

alter function dataporextenso(date) owner to unico;

