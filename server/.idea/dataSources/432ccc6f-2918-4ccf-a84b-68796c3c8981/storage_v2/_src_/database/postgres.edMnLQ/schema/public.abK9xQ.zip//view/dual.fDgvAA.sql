create view dual(id) as
SELECT 'X'::text AS id;

alter table dual
    owner to unico;

