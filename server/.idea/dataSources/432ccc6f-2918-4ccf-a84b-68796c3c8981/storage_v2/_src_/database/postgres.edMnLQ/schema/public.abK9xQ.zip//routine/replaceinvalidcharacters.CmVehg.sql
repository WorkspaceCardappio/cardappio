create function replaceinvalidcharacters(schemaname character varying, tablename character varying) returns integer
    language plpgsql
as
$$
             DECLARE columnName character varying;
           BEGIN
             RAISE NOTICE 'Execute replaceInvalidCharacters for (%,%)', tableName,schemaName;
             FOR columnName IN SELECT column_name
              FROM information_schema.columns
              WHERE table_schema = schemaName
              AND table_name   =  tableName
              AND data_type = 'character varying'
             LOOP
               RAISE NOTICE 'update column %', columnName;
               EXECUTE 'UPDATE '|| schemaName || '.'||tableName|| ' SET '|| columnName ||
                 ' = regexp_replace('||columnName||',E''\\x81|\x8D|\x8F|\x90|\x9D'','''') WHERE '|| columnName || ' ~ E''\x81|\x8D|\x8F|\x90|\x9D''';
             END LOOP;
             RETURN 1; 
           END;
           $$;

alter function replaceinvalidcharacters(varchar, varchar) owner to unico;

